package Objetos;


/**
 * metodos comunes que son accedidos mediante herencia
 *
 */
public abstract class Motor {
	public String TipoMotor="";
	abstract public void encender();
	abstract public void acelerar();
	abstract public void apagar();
}


