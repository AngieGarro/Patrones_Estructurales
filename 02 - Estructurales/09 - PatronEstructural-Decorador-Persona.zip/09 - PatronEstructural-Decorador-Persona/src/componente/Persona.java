package componente;

public abstract class Persona {
	public abstract int 	getVelocidad() ;
	public abstract String 	getNombre() ;
	public abstract String 	getTipo();
}
