package bridge.color;

import bridge.abstracta.IColor;

public class Negro implements IColor {
	
    @Override
    public void pintar() {
        System.out.println("Color Negro");
    }

	@Override
	public String getColor() {
		return "Negro";
	}
    
}
