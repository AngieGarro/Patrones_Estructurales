/***************************************************************************
 * Clase: Fachada Coffee Maker.
 * Descripción: esta clase permite ocultar la complejidad de la maquina de 
 * hacer cafe, al reducir las opciones que el usuario tiene para poder 
 * obtener su café. Intenamente hace los mismos llamados que al usuario
 * de la forma clasica le tocaria hacer. 
 ***************************************************************************/
package clases;

import objetos.Receta;

public class Fachada_CoffeMaker {
	private maquina_cafe old_mc; 
	private Receta ownReceta;
	
	public Fachada_CoffeMaker (){
		old_mc = new maquina_cafe();
		ownReceta = new Receta();
	}
		
	public String mostrarMenu() {
		return ("Bienvenido, la maquina de café esta en linea \n"
				+ "\n Seleccione la bebida a preparar \n"
				+ "1. Cafe Negro \n"
				+ "2. Cafe con leche\n"
				+ "3. Cafe Expresso\n"
				+ "4. Capuchino\n"
				+ "5. Cancelar\n");
	}
	
	
	public String ejectuar_funcion(int pIdx) {
		switch (pIdx){
			case 1: 
				ownReceta.Cafe_Negro();
				break;
			case 2: 
				//ownReceta.Cafe_Con_Leche();
				break;
			case 3: 
				//ownReceta.Cafe_Expresso();
				break;
			case 4: 
				//ownReceta.Cafe_Capuchino();
				break;
			case 5: 
				return "Lo esperamos pronto";
			
			default: 
				return "No es una opcion valida";
		}
		
		return hacer_cafe (ownReceta.getCantidad_Cafe(), 
						   ownReceta.getCantidad_Agua(),
						   ownReceta.getCantidad_Leche(),
						   ownReceta.getNombre());
	}
	
	
	private String hacer_cafe(int cantCafe, int cantAgua, int cantLeche, String tipoCafe) {
		String mData = "No se pudo hacer el cafe";
		boolean bLec = false;
		
		if(cantLeche > 0) 
			bLec = true;
		
		if( old_mc.revisarStockVasos(0) && old_mc.revisarNivelAgua(0,cantAgua) && 
				old_mc.revisarStockCafe(cantCafe) && old_mc.revisarNivelLeche(cantLeche)) {
			mData = "LOG { \n";
			mData += "      " + old_mc.colocarCafe(cantCafe);
			mData += "      " + old_mc.colocarVaso(0);
			mData += "      " + old_mc.calentarAgua();
			if (bLec)
				mData += "      " + old_mc.verterLeche(cantLeche);
			mData += "      " + old_mc.verterAgua(cantAgua) + "}\n";
			mData += old_mc.servirCafe() + tipoCafe+"\n\n\n\n\n";		
		}
		
		
		
		
		return mData;
	}
	
}
