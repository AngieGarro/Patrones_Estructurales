package principal;


public class Main_Taller_Mecanico {

	public static void main(String[] args) {
		Gestor_taller_mecanico gs = new Gestor_taller_mecanico();
		System.out.println(gs.map_Main());
		
	}
	
}

/****************************************************************
* TAREA:
* - Hacer un menu interactivo con el usuario.
* - Separar la creación de la parte INTRINSICOS de la EXTRINSECA
* para que cuando llegue un cliente entra al taller el encargado 
* cree el vehiculo y si decide dejarlo rellena los datos que faltan. 
* - Crear un nuevo modelo.
*****************************************************************/
