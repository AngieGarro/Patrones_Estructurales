package principal;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import modulo.util;
import objetos.Extrinseco.vehiculo;

public class Gestor_taller_mecanico {
	public String map_Main() {
		String resultado = "";
		Map<String, vehiculo> mpCar = new HashMap<String,vehiculo>();
		vehiculo mCar = null;
		resultado = "-----------------------------";
		resultado = "Sistema del taller mecanico. ";
		resultado = "-----------------------------";
		
		for (int i=1; i<6 ; i++) {
			mCar = generar(i);
			mpCar.put(mCar.getVehiculoKey(),mCar);
		}
		
		resultado = "-----------------------------";
		resultado = "----------------------------- \n";
		
		util.imprimirMapaCarros(mpCar);
		return resultado;	
	}
	
	
	@SuppressWarnings("deprecation")
	private static vehiculo generar(int i) {
		vehiculo mCar = null;
		switch(i) {
		  case 1:
			  mCar = new vehiculo("Mercury", "Bobcat", "Verde", "ABC-123", 
				        new Date(2019, 07, 14), "1-0123-0456");
		    break;
		  case 2:
			  mCar = new vehiculo("Mercury", "Bobcat", "Azul", "CAB-123", 
				  		new Date(2010, 01, 01), "1-0456-0123");
		    break;
		  case 3:
			  mCar = new vehiculo("Pontiac", "GXP", "Rojo", "PKA-002" , 
				  		new Date(2018, 04, 25), "1-0444-0555");
			break;
		  case 4:
			  mCar = new vehiculo("Pontiac", "GXP", "Rojo","CCC-123", 
				        new Date(2019, 07, 14), "1-0123-0456");
			 break;
		  case 5:
			  mCar = new vehiculo("Mercury", "Bobcat", "Verde", "PPP-111", 
				        new Date(2019, 07, 14), "1-9876-5432");
			 break;
		  default:
		   
		}
		return mCar;
	}
}
