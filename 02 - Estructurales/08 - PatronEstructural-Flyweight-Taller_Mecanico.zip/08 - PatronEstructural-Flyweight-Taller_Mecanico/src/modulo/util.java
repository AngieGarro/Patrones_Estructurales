/* ********************************************************************** *
 * Clase que brinda funciones reutilizables.
 * 
 * @by Erick Brenes
 * ********************************************************************** */
package modulo;

import java.util.Map;
import objetos.*;
import objetos.Extrinseco.vehiculo;
import objetos.clasico.vehiculoC;

public class util {
	
/* ********************************************************************** *
 * Funcion de impresion para el manejo de la clase MAP esto nos permite el
 * manejo de una estructura de datos para almacenar pares "clave/valor". 
 * De tal manera que para una clave solamente tenemos un valor. 
 * ********************************************************************** */
	public static void imprimirMapaCarros(Map<String,vehiculo> map) {
		vehiculo mvc;
		for(Map.Entry m:map.entrySet()){  
		  mvc = (vehiculo) m.getValue();
		  System.out.println(m.getKey()+" "+mvc.MostrarCaracteristicas());  
		}  
	}
	
	public static void imprimirMapaCarrosC(Map<String,vehiculoC> map) {
		vehiculoC mvc;
		for(Map.Entry m:map.entrySet()){  
		  mvc = (vehiculoC) m.getValue();
		  System.out.println(m.getKey()+" "+mvc.MostrarCaracteristicas());  
		}  
	}
	
	public static void imprimirIntegranteMapa(String pKey, MarcaModelo pVeh) {
		System.out.println(pKey+" "+ pVeh.MostrarCaracteristicas(""));
	}
	
	public static void imprimirIntegranteMapa(String pKey, MarcaModelo pVeh, String pData) {
		System.out.println(pKey+" "+ pVeh.MostrarCaracteristicas(pData));
	}
	
	public static String generarKey(String pMarca, String pModelo, String pColor) {
		return pMarca+"-"+pModelo+"-"+pColor;
	}
 
	public static void imprimirMapaMarcaModelo(Map<String, MarcaModelo> gPoolCar) {
		MarcaModelo mvc;
		for(Map.Entry m:gPoolCar.entrySet()){  
		  mvc = (MarcaModelo) m.getValue();
		  System.out.println(m.getKey()+" "+mvc.MostrarCaracteristicas(""));  
		}  
	}


}
