package objetos.Extrinseco;

import java.util.Date;

import objetos.MarcaModelo;
import objetos.VehiculoFactory;

public class vehiculo {
	// Datos INTRINSICOS  encapsulados en la clase objetos.MarcaModelo
    private MarcaModelo datosImplicitos;
	
    //Datos EXTRINSECA
    public String Placa;
    public Date FechaMatriculacion;
    public String Cedula;
    
    public vehiculo(String pMarca, String pModelo, String pColor, 
    				String pPlaca, Date pFechaMatriculacion, String pCedula) {
    	
    	
    	
    	datosImplicitos = VehiculoFactory.obtenerCarro(pMarca, pModelo, pColor);
    	
    	
    	setDatosExtrinsecos(pPlaca, pFechaMatriculacion, pCedula);
	}
	public String MostrarCaracteristicas(){
        return  datosImplicitos.MostrarCaracteristicas(getDatosVehiculo());
    }
	public String getVehiculoKey() {
		return   datosImplicitos.Marca + "-"
				+ datosImplicitos.Modelo + "-"
				+ datosImplicitos.Color;
	}

/* ********************************************************************** *	
 * Sección de funciones publicas del área EXTRINSECA. Estas funciones 
 * ayudan para mostrar los datos EXTRINSESCOS del objeto, osea los que 
 * no deberian de variar. Por eso solo muestran datos.
 * ********************************************************************** */
	public String getPlaca() {
		return Placa;
	}
	public String getCedula() {
		return Cedula;
	}
	public Date getFechaMatriculacion() {
		return FechaMatriculacion;
	}
	public String getDatosVehiculo() {
		return   " Placa:" + getPlaca() + " \n"
				+ " Cédula:" + getCedula() + " \n"
	       	 	+ " Fecha de inscripción:" + getFechaMatriculacion() + " \n";
	}

/* ********************************************************************** *	
 * Sección de funciones privadas. Sirven para modificar datos. 
 * Estos datos no deberían variar con el tiempo (son comunes a todas las 
 * instancias). Estas funciones son para manejar los datos EXTRINSECOS
 * ********************************************************************** */
	private void setDatosExtrinsecos(String pPlaca, Date pFechaMatriculacion, String pCedula) {
		setPlaca(pPlaca);
		setFechaMatriculacion(pFechaMatriculacion);
		setCedula(pCedula);
	}
	private void setPlaca(String placa) {
		Placa = placa;
	}
	private void setFechaMatriculacion(Date fechaMatriculacion) {
		FechaMatriculacion = fechaMatriculacion;
	}
	private void setCedula(String cedula) {
		Cedula = cedula;
	}
}
