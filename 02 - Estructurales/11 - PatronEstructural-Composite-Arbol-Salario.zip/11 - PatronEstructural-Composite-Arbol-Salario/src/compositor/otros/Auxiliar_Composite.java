/*****************************************************************************
 * Descripcion: Esta es una clase auxiliar, este tipo de clases se hacen 
 * para ayudar a entender (organizar) mejor el codigo del patron. Por lo tanto
 * esta clase no es parte de la estructura del patr�n. 
 ******************************************************************************/
package compositor.otros;

import java.util.ArrayList;

import compositor.base.IEmpresa;
import compositor.componentes.*;

public class Auxiliar_Composite {
	private ArrayList<IEmpresa> _Empresas;
	private ArrayList<IEmpresa> _Equipos;
	private ArrayList<IEmpresa> _Empleados;
	
	public Auxiliar_Composite() {
		for (int i=1; i<4; i++)
			setComponentes(i, new ArrayList<IEmpresa>());
	}
	
	public String infoTipoObjetos() {
		return "1. Empresa.\n"
			 + "2. Equipo.\n"
			 + "3. Empleado.\n";
	}

	public void nuevoComponente(int pTipo, String pNombre) {
		IEmpresa temp = null;
		switch(pTipo) {
			case 1:
				temp = new Empresa(pNombre);
				break;
			case 2:
				temp = new Equipo(pNombre);
				break;
		}
		addComponentes(pTipo, temp);
	}
	
	public void nuevoComponente(int pTipo, String pNombre, int pSalario) {
		addComponentes(pTipo, new Empleado(pSalario, pNombre));
	}
	
	public void agregarHoja(int pTipoHijo, String pNombreHijo, String pNombrePadre) {
		IEmpresa padre = findComponente(pTipoHijo - 1, pNombrePadre);
		IEmpresa hijo = findComponente(pTipoHijo, pNombreHijo);
		
		if(padre != null && hijo != null)
			padre.agregarComponente(hijo);
	}
	
	public int obtenerSalario(int pTipo, String pNombre) {
		IEmpresa temp = findComponente(pTipo, pNombre);
		
		if (temp != null)
			return temp.getSalario();
		
		return -1;	
	}
	
	public String obtenerDescripcion(int pTipo, String pNombre) {
		IEmpresa temp = findComponente(pTipo, pNombre);
		
		if (temp != null)
			return temp.mostrarDatos();
		
		return "";	
	}
	
	public ArrayList<String> obtenerLista(int pTipo){
		ArrayList<IEmpresa> tempArr = getComponentes (pTipo);
		ArrayList<String> lista = new ArrayList<String>();
		
		for (IEmpresa item : tempArr) 
	         lista.add(item.getNombre());
	    
		return lista;
	}
	
	private IEmpresa findComponente(int pTipo, String pNombre) {
		ArrayList<IEmpresa> tempArr = null;
		
		switch(pTipo) {
			case 1:
				tempArr = this._Empresas;
				break;
			case 2:
				tempArr = this._Equipos;
				break;
			case 3:
				tempArr = this._Empleados;
				break;
		}
		
		for (IEmpresa item : tempArr) {
	        if (item.getNombre().equals(pNombre)) {
	        	return item;
	        }
	    }
		
		return null;
	}
	
	private void setComponentes(int pTipo, ArrayList<IEmpresa> pComponente) {
		switch(pTipo) {
			case 1:
				this._Empresas = pComponente;
				break;
			case 2:
				this._Equipos = pComponente;
				break;
			case 3:
				this._Empleados = pComponente;
				break;
		}
	}
	
	private  ArrayList<IEmpresa> getComponentes(int pTipo) {
		switch(pTipo) {
			case 1:
				return this._Empresas;
			case 2:
				return this._Equipos;
			case 3:
				return this._Empleados;
				
		}
		return null;
	}
	
	private void addComponentes(int pTipo, IEmpresa pComponente) {
		switch(pTipo) {
			case 1:
				this._Empresas.add(pComponente);
				break;
			case 2:
				this._Equipos.add(pComponente);
				break;
			case 3:
				this._Empleados.add(pComponente);
				break;
		}
	}
	
	
}
