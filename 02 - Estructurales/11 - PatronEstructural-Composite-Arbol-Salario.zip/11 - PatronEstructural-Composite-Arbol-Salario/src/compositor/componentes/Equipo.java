package compositor.componentes;

import java.util.ArrayList;
import compositor.base.IEmpresa;

public class Equipo extends IEmpresa{
	private ArrayList<IEmpresa> listaComposicion; //Contiene empleados
	
	public Equipo(String pNombre) {
		this.setTipoNodo( IEmpresa.EQUIPO);
		this.setNombre(pNombre);
		this.listaComposicion = new ArrayList<IEmpresa>();
	}
	
	
	
	@Override
	public int getSalario() {
		int total=0;
        for (IEmpresa nodo : listaComposicion)
        	total += nodo.getSalario();
       
		return total;
	}
	
	@Override
	public void agregarComponente(IEmpresa composicion) {
		this.listaComposicion.add(composicion);
	}

	@Override
	public String mostrarDatos() {
		String mLin1="" , mLine2 = "";
		mLin1 = "Listando Equipo \"" + this.getNombre() + "\""+". [Total $" + getSalario() +"] \n" ;
        for (IEmpresa nodo : listaComposicion)
        	mLine2 += nodo.mostrarDatos();
       
		return mLin1 + mLine2 +"\n";
	}
}