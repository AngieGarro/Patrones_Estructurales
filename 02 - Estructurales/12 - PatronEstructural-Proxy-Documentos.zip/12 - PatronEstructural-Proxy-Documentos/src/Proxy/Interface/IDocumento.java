package Proxy.Interface;

public interface IDocumento {
 
	 public void acceder(String usuario);
	 public void cargarImagen(int pagina);

}