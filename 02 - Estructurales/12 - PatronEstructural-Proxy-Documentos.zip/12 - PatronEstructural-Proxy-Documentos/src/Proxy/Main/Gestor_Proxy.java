package Proxy.Main;

import Proxy.Implementacion.*;
import Proxy.Interface.IDocumento;

public class Gestor_Proxy {
	IDocumento mDP;
	
	Gestor_Proxy(){
		mDP = new DocumentoProxy();
	}
	
	public void accederDocumento(String pUser, int pPage) {
		mDP.acceder(pUser);
		mDP.cargarImagen(pPage);
	}
}
