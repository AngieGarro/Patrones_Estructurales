package Proxy.Main;

public class Principal_Proxy {
	static Gestor_Proxy gestor;
	
	public static void main(String[] args) {
		gestor = new Gestor_Proxy();
		
		imprimir("Profesor accediendo la pagina 1:");
		imprimir("--------------------------------");
		gestor.accederDocumento("Profesor", 1);
		
		imprimir("\n\nProfesor accediendo la pagina 2:");
		imprimir("--------------------------------");
		gestor.accederDocumento("Profesor", 2);
		
		imprimir("\n\nEstudiante accediendo la pagina 1:");
		imprimir("----------------------------------");
		gestor.accederDocumento("Estudiante", 1);
		
		imprimir("\n\nEstudiante accediendo la pagina 2:");
		imprimir("----------------------------------");
		gestor.accederDocumento("Estudiante", 2);
	}
	
	private static void imprimir(String pTexto) {
		System.out.println(pTexto);
	}
}