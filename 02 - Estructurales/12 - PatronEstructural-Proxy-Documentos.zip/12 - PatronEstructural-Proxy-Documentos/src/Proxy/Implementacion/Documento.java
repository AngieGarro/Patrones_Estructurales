package Proxy.Implementacion;

import Proxy.Interface.IDocumento;

public class Documento implements IDocumento{

	@Override
	public void acceder(String usuario) {
		System.out.println("Abriendo el documento...");
		
	}

	@Override
	public void cargarImagen(int pPagina) {
		System.out.println("Cargando la Imagen: "+ pPagina);
		
	} 
	
}