package Proxy.Implementacion;

import Proxy.Interface.IDocumento;

public class DocumentoProxy implements IDocumento {
	private Documento doc = new Documento();
	private boolean apertura;
	
	@Override
	public void acceder(String usuario) {
		if ("Profesor".equals(usuario)) {
			System.out.println("Usuario sin permisos");
			apertura = false;
		}else {
		   doc.acceder(usuario);
		   apertura = true;
		}
	}

	@Override
	public void cargarImagen(int pagina) {
		if ((pagina % 2 == 0) && apertura) 
			doc.cargarImagen(pagina);	
		else
			System.out.println("Luego se cargara la imagen");  
	}
	
}